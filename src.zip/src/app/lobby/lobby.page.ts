import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, NavController, ToastController } from '@ionic/angular';
import { CanComponentDeactivate } from '../candeactivate.guard';
import { AuthService } from '../auth.service';
import { Storage } from '@ionic/storage-angular';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-lobby',
  templateUrl: './lobby.page.html',
  styleUrls: ['./lobby.page.scss'],
})
export class LobbyPage implements CanComponentDeactivate, OnInit, OnDestroy {
  nombre_usuario: string = '';
  audio: any;
  song: Array<{ title: string; path: string }> = [
    { title: 'Cancion 1', path: 'assets/audio/a.mp3' },
  ];
  cancionActual: number = 0;
  nombreAlmacenado: string | null = null;
  posts: any[] = [];
  loading: boolean = true;

  constructor(
    private toastController: ToastController,
    private router: Router,
    private alertController: AlertController,
    private authService: AuthService,
    private storage: Storage,
    private apiService: ApiService,
    private navCtrl: NavController
  ) {
    this.initStorage();
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'bottom'
    });
    toast.present();
  }


  async initStorage() {
    await this.storage.create();
    await this.obtenerNombre();
  }


  cargarCancion(index: number) {
    if (this.audio) {
      this.audio.pause();
      this.audio = null;
    }
    this.cancionActual = index;
    this.storage.set('cancionActual', index); 
    this.audio = new Audio(this.song[index].path);
    this.audio.play();

    this.audio.onended = () => {
      console.log('Canción terminada');
      this.audio = null; 
    };
  }


  async obtenerNombre() {
    this.nombreAlmacenado = await this.storage.get('nombre');
    console.log('Nombre almacenado:', this.nombreAlmacenado);
  }

  async ngOnInit() {
    this.cancionActual = (await this.storage.get('cancionActual')) || 0;
    this.cargarCancion(this.cancionActual);

    const lastViewedPost = await this.storage.get('lastViewedPost');
    if (lastViewedPost) {
      console.log("Último post visto:", lastViewedPost);
   
    }

    this.loading = true;
    this.apiService.getPosts().subscribe(
      (data: any) => {
        this.posts = data;
        this.loading = false;
      },
      (error) => {
        console.error("Error al cargar los posts", error);
        this.loading = false;
      }
    );
  }
  updatePost(postId: number, updatedData: any) {
    this.apiService.updatePost(postId, updatedData).subscribe((updatedPost) => {
    
      const index = this.posts.findIndex(post => post.id === postId);
      if (index !== -1) {
        this.posts[index] = updatedPost;
        this.presentToast('Post editado correctamente');
      }
    });
  }
  createPost() {
    this.alertController.create({
      header: 'Nuevo Post',
      inputs: [
        { name: 'title', type: 'text', placeholder: 'Título' },
        { name: 'body', type: 'text', placeholder: 'Contenido' }
      ],
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Agregar',
          handler: (data) => {
            const newPost = { title: data.title, body: data.body };
            this.apiService.createPost(newPost).subscribe(() => {
              this.presentToast('Post creado exitosamente'); 
              this.loadPosts();
            });
          }
        }
      ]
    }).then(alert => alert.present());
  }
  loadPosts() {
    this.loading = true;
    this.apiService.getPosts().subscribe(
      (data: any) => {
        this.posts = data;
        this.loading = false;
      },
      (error) => {
        console.error("Error al cargar los posts", error);
        this.loading = false;
      }
    );
  }
  editPost(id: number) {
    console.log('Editando el post con ID:', id);
    this.navCtrl.navigateForward('/edit', {
      state: {
        postId: id,
        fromEdit: true 
      },
    });
  }


  canDeactivate(navigationState?: { fromLogout?: boolean }): boolean {
    const navigation = this.router.getCurrentNavigation();
    const fromEdit = navigation?.extras.state?.['fromEdit'];
    const fromLogout = navigationState?.fromLogout;
    
   
    if (!fromEdit && fromLogout) {
      return confirm('¿Estás seguro que deseas cerrar sesión?');
    }
    return true;
  }

  logout() {
    if (this.canDeactivate({ fromLogout: true })) {
      this.authService.logout();
      this.router.navigate(['/home']);
    }
  }

  async presentAlert(header: string, subHeader: string, message: string) {
    const alert = await this.alertController.create({
      header: header,
      subHeader: subHeader,
      message: message,
      buttons: ['OK'],
    });

    await alert.present();
  }

  deletePost(id: number) {
    this.apiService.deletePost(id).subscribe(() => {
      this.posts = this.posts.filter(post => post.id !== id);
      this.presentToast('Post eliminado correctamente');
    });
  }

  viewPost(postId: number) {
    this.storage.set('lastViewedPost', postId);
    console.log("Post visto guardado:", postId);
  }


  ngOnDestroy() {
    if (this.audio) {
      this.audio.pause();
      this.audio = null;
    }
  }

 
  trackByPostId(index: number, post: any): number {
    return post.id;
  }
}
